import type { APIRoute } from 'astro';
import { isAdminRequest, unauthorizedResponse } from '../../../lib/admin-auth';
import { cleanText, logCmsAction, readJsonRequest, isPlainRecord } from '../../../lib/cms-admin';
import { getSupabaseAdmin } from '../../../lib/supabase';

export const prerender = false;
type Kind = 'guru' | 'skills';
const tableFor = (kind: Kind) => kind === 'guru' ? 'guru' : 'skills';

export const GET: APIRoute = async ({ request, url }) => {
  if (!isAdminRequest(request)) return unauthorizedResponse();
  const kind = url.searchParams.get('type') as Kind;
  if (!['guru', 'skills'].includes(kind)) return Response.json({ error: 'Jenis koleksi tidak dikenal.' }, { status: 400 });
  const db = getSupabaseAdmin();
  if (!db) return Response.json({ error: 'Supabase belum tersedia.' }, { status: 503 });
  const { data, error } = await db.from(tableFor(kind)).select('*').order('urutan');
  if (error) return Response.json({ error: 'Koleksi gagal dibaca.' }, { status: 500 });
  return Response.json({ data: data || [] }, { headers: { 'Cache-Control': 'no-store' } });
};

export const PUT: APIRoute = async ({ request, url }) => {
  if (!isAdminRequest(request)) return unauthorizedResponse();
  const kind = url.searchParams.get('type') as Kind;
  if (!['guru', 'skills'].includes(kind)) return Response.json({ error: 'Jenis koleksi tidak dikenal.' }, { status: 400 });
  const db = getSupabaseAdmin();
  if (!db) return Response.json({ error: 'Supabase belum tersedia.' }, { status: 503 });
  const parsedBody = await readJsonRequest(request, 262144);
  if (parsedBody.error === 'too_large') return Response.json({ error: 'Ukuran JSON melebihi batas yang diizinkan.' }, { status: 413 });
  if (parsedBody.error || !isPlainRecord(parsedBody.data)) return Response.json({ error: 'JSON tidak valid.' }, { status: 400 });
  const body = parsedBody.data as any;
  if (!Array.isArray(body?.items) || body.items.length > 100 || body.items.some((item: unknown) => !isPlainRecord(item))) return Response.json({ error: 'Data koleksi harus berupa daftar maksimal 100 object.' }, { status: 400 });
  const isGuru = kind === 'guru';
  if (isGuru && body.items.some((item: any) => item.expertise !== undefined && (!Array.isArray(item.expertise) || item.expertise.length > 20 || item.expertise.some((entry: unknown) => typeof entry !== 'string')))) return Response.json({ error: 'Expertise guru harus berupa daftar maksimal 20 teks.' }, { status: 400 });
  if (!isGuru && body.items.some((item: any) => item.level !== undefined && (typeof item.level !== 'number' && !(typeof item.level === 'string' && item.level.trim() !== '') || !Number.isFinite(Number(item.level))))) return Response.json({ error: 'Level keahlian harus berupa angka yang valid.' }, { status: 400 });
  const normalized = body.items.map((item: any, index: number) => isGuru ? ({
    nama: cleanText(item.nama, 160), mapel: cleanText(item.mapel, 180), peran: cleanText(item.peran, 180),
    quote: cleanText(item.quote, 1000), expertise: Array.isArray(item.expertise) ? item.expertise.slice(0, 20) : [], urutan: index,
    updated_at: new Date().toISOString(),
  }) : ({
    nama: cleanText(item.nama, 160), level: Math.max(0, Math.min(100, Number(item.level) || 0)), icon: cleanText(item.icon, 80),
    deskripsi: cleanText(item.deskripsi ?? item.desc, 1000), urutan: index, updated_at: new Date().toISOString(),
  }));
  if (normalized.some((item: any) => !item.nama)) return Response.json({ error: 'Setiap item wajib memiliki nama.' }, { status: 400 });
  const uniqueNames = new Set(normalized.map((item: any) => item.nama));
  if (uniqueNames.size !== normalized.length) return Response.json({ error: 'Nama item koleksi tidak boleh duplikat.' }, { status: 400 });
  const { data: existing, error: existingError } = await db.from(tableFor(kind)).select('nama');
  if (existingError) return Response.json({ error: 'Data koleksi sebelumnya gagal dibaca.' }, { status: 500 });
  const keep = new Set(normalized.map((item: any) => item.nama));
  const removed = (existing || []).filter((row) => !keep.has(row.nama)).map((row) => row.nama);
  if (removed.length && body.confirmReplace !== true) {
    return Response.json({ error: `Penyimpanan ini akan menghapus ${removed.length} item lama. Konfirmasi penggantian diperlukan.`, removed }, { status: 409 });
  }
  if (normalized.length) {
    const { error } = await db.from(tableFor(kind)).upsert(normalized, { onConflict: 'nama' });
    if (error) return Response.json({ error: 'Koleksi gagal disimpan.' }, { status: 500 });
  }
  for (const row of existing || []) {
    if (!keep.has(row.nama)) {
      const { error: deleteError } = await db.from(tableFor(kind)).delete().eq('nama', row.nama);
      if (deleteError) return Response.json({ error: `Data ${kind} tersimpan, tetapi penghapusan '${row.nama}' gagal. Muat ulang data sebelum mencoba lagi.` }, { status: 500 });
    }
  }
  await logCmsAction(db, 'replace', kind, null, `${normalized.length} item ${kind} disimpan`);
  return Response.json({ ok: true, data: normalized });
};
